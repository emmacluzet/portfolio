﻿using System;
using System.Drawing; // Importe l'espace de noms System.Drawing pour les classes liées aux graphismes, comme Brushes et Graphics, utilisées pour dessiner les allumettes
using System.Windows.Forms; // Importe l'espace de noms System.Windows.Forms pour les classes Windows Forms, comme Form, Label, Button et Panel, pour créer l'interface graphique

namespace JeuAllumettes // Définit l'espace de noms "JeuAllumettes" pour organiser le code et éviter les conflits de noms
{
    public class JeuAllumettesForm : Form // Définit une classe "JeuAllumettesForm" qui hérite de Form, en faisant une fenêtre Windows Forms
    {
        private int nbAllumettes; // Déclare un champ privé de type entier pour stocker le nombre d'allumettes restantes (commence à 20)
        private bool tourJoueur; // Déclare un champ privé de type booléen pour indiquer à qui est le tour (true pour le joueur, false pour l'ordinateur)
        private int numeroTour; // Déclare un champ privé de type entier pour suivre le numéro du tour actuel
        private Label? lblStatus; // Déclare un champ privé nullable de type Label pour afficher l'état du jeu (par exemple, tour ou résultat). Nullable pour respecter les règles de null-safety
        private Label? lblAllumettes; // Déclare un champ privé nullable de type Label pour afficher le nombre d'allumettes restantes
        private Button? btnPrendre1; // Déclare un champ privé nullable de type Button pour le bouton permettant de prendre 1 allumette
        private Button? btnPrendre2; // "" 2 allumettes
        private Button? btnPrendre3; // ""3 allumettes
        private Button? btnRejouer; // Déclare un champ privé nullable de type Button pour le bouton "Rejouer", visible uniquement à la fin du jeu
        private Panel? panelAllumettes; // Déclare un champ privé nullable de type Panel pour la zone où les allumettes sont dessinées

        // Constructeur de la classe JeuAllumettesForm, appelé lors de la création de la fenêtre
        public JeuAllumettesForm()
        { 
            InitializeGame(); // méthode InitializeGame: initialise l'état du jeu (nombre d'allumettes, tour, etc.)
            InitializeComponents(); // méthode InitializeComponents: créer et configurer les éléments graphiques (étiquettes, boutons, panneau)
        }

        // Méthode pour initialiser ou réinitialiser l'état du jeu
        private void InitializeGame() 
        {
            nbAllumettes = 20; // Définit le nombre initial d'allumettes à 20
            tourJoueur = true; // Indique tour du joueur (true = joueur commence)
            numeroTour = 1; // Définit le numéro du tour à 1 (premier tour)
        }

        // Méthode pour configurer les composants graphiques de la fenêtre
        private void InitializeComponents() 
        {
            // Configuration de la fenêtre
            this.Text = "Jeu des Allumettes"; // titre de la fenêtre "Jeu des Allumettes"
            this.Size = new Size(600, 400); // taille fenêtre 600 pixels de large et 400 pixels de haut
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Rend fenêtre non redimensionnable avec bordure fixe
            this.MaximizeBox = false; // Désactive bouton d'agrandissement pour empêcher le redimensionnement

            // Panel pour afficher les allumettes
            panelAllumettes = new Panel // Crée un nouvel objet Panel pour dessiner les allumettes
            {
                Location = new Point(20, 20), // Positionne le panneau à 20 pixels du haut et de la gauche de la fenêtre
                Size = new Size(540, 100), // Définit la taille du panneau à 540 pixels de large et 100 pixels de haut
                BorderStyle = BorderStyle.FixedSingle // Ajoute une bordure simple autour du panneau pour plus de clarté visuelle
            };
            panelAllumettes.Paint += DessinerAllumettes; // Associe la méthode DessinerAllumettes à l'événement Paint du panneau, déclenché lorsque le panneau doit être redessiné
            this.Controls.Add(panelAllumettes); // Ajoute le panneau à la collection de contrôles de la fenêtre, le rendant visible

            // Label pour le statut
            lblStatus = new Label // Crée un nouvel objet Label pour afficher l'état du jeu
            {
                Location = new Point(20, 130), // Positionne l'étiquette à (20, 130), sous le panneau
                Size = new Size(540, 30), // Définit la taille de l'étiquette à 540 pixels de large et 30 pixels de haut
                Text = "Tour 1 - Joueur : Choisissez 1, 2 ou 3 allumettes", // Définit le texte initial pour indiquer le tour du premier joueur
                Font = new Font("Arial", 12) // Définit la police à Arial, taille 12
            };
            this.Controls.Add(lblStatus); // Ajoute l'étiquette de statut aux contrôles de la fenêtre

            // Label pour le nombre d'allumettes
            lblAllumettes = new Label // Crée un nouvel objet Label pour afficher le nombre d'allumettes restantes
            {
                Location = new Point(20, 160), // Positionne l'étiquette à (20, 160), sous l'étiquette de statut
                Size = new Size(540, 30), // Définit la taille de l'étiquette à 540 pixels de large et 30 pixels de haut
                Text = $"Allumettes restantes : {nbAllumettes}", // Définit le texte initial pour afficher le nombre d'allumettes (20)
                Font = new Font("Arial", 12) // Définit la police à Arial, taille 12
            };
            this.Controls.Add(lblAllumettes); // Ajoute l'étiquette des allumettes aux contrôles de la fenêtre

            // Boutons pour prendre des allumettes
            btnPrendre1 = new Button // Crée un nouvel objet Button
            {
                Text = "Prendre 1", // Définit le texte du bouton à "Prendre 1"
                Location = new Point(20, 200), // Positionne le bouton à (20, 200)
                Size = new Size(100, 40), // taille bouton 100px de large et 40px de haut
                Enabled = true // Active le bouton (cliquable par défaut
            };
            btnPrendre1.Click += (s, e) => JouerTour(1); // s: sender   e:EventArgs
            this.Controls.Add(btnPrendre1); // Ajoute le bouton aux contrôles de la fenêtre.

            // Crée un nouvel objet Button pour prendre 2 allumettes.
            btnPrendre2 = new Button 
            {
                Text = "Prendre 2", // Définit le texte du bouton à "Prendre 2".
                Location = new Point(130, 200), // Positionne le bouton à (130, 200), à droite de btnPrendre1.
                Size = new Size(100, 40), // Définit la taille du bouton à 100 pixels de large et 40 pixels de haut.
                Enabled = true // Active le bouton.
            };
            // Associe une expression lambda pour appeler JouerTour avec 2 allumettes.
            btnPrendre2.Click += (s, e) => JouerTour(2); // Associe une expression lambda à l'événement Click du bouton, appelant JouerTour avec 2 allumettes.
            this.Controls.Add(btnPrendre2); // Ajoute le bouton aux contrôles de la fenêtre.

            // Crée un nouvel objet Button pour prendre 3 allumettes.
            btnPrendre3 = new Button 
            {
                Text = "Prendre 3", // Définit le texte du bouton à "Prendre 3".
                Location = new Point(240, 200), // Positionne le bouton à (240, 200), à droite de btnPrendre2.
                Size = new Size(100, 40), // Définit la taille du bouton à 100 pixels de large et 40 pixels de haut.
                Enabled = true // Active le bouton.
            };
            btnPrendre3.Click += (s, e) => JouerTour(3); // Associe une expression lambda pour appeler JouerTour avec 3 allumettes.
            this.Controls.Add(btnPrendre3); // Ajoute le bouton aux contrôles de la fenêtre.

            // Bouton pour rejouer
            btnRejouer = new Button // Crée un nouvel objet Button pour relancer le jeu.
            {
                Text = "Rejouer", // Définit le texte du bouton à "Rejouer".
                Location = new Point(20, 250), // Positionne le bouton à (20, 250), sous les autres boutons.
                Size = new Size(100, 40), // Définit la taille du bouton à 100 pixels de large et 40 pixels de haut.
                Visible = false // Rend le bouton invisible au départ (visible uniquement à la fin du jeu).
            };
            btnRejouer.Click += BtnRejouer_Click; // Associe la méthode BtnRejouer_Click à l'événement Click du bouton.
            this.Controls.Add(btnRejouer); // Ajoute le bouton de rejouer aux contrôles de la fenêtre.

            // Afficher les règles au démarrage
            MessageBox.Show("Règles du jeu des Allumettes :\n- 20 allumettes au départ\n- Prenez 1, 2 ou 3 allumettes à chaque tour\n- Celui qui prend la dernière allumette perd !", "Règles"); // Affiche une boîte de dialogue avec les règles du jeu au démarrage.
        }

        // Gestionnaire d'événement pour le clic sur le bouton "Rejouer". Le paramètre sender est nullable pour respecter les règles de nullabilité.
        private void BtnRejouer_Click(object? sender, EventArgs e) 
        {
            Rejouer(); // Appelle la méthode Rejouer pour réinitialiser et relancer le jeu.
        }

        // Gestionnaire d'événement pour l'événement Paint du panneau, déclenché pour dessiner les allumettes.
        private void DessinerAllumettes(object? sender, PaintEventArgs e) 
        {
            if (panelAllumettes == null) return; // Vérifie si panelAllumettes est null
            Graphics g = e.Graphics; // Récupère l'objet Graphics depuis les arguments de l'événement pour dessiner
            for (int i = 0; i < nbAllumettes; i++) // Boucle pour dessiner chaque allumette restante
            {
                g.FillRectangle(Brushes.BlueViolet, 20 + i * 25, 20, 15, 60); // Dessine un rectangle violet (allumette) à la position (20 + i*25, 20), de taille 15x60 pixels
            }
        }
        // Méthode pour vérifier si le jeu est terminé.
        private bool Fin()
        {
            return nbAllumettes <= 0;
        }

        // Méthode pour gérer un tour de jeu, où nb est le nombre d'allumettes à prendre
        private void JouerTour(int nb)
        {
            if (Fin()) return; // Si le jeu est terminé (aucune allumette restante), quitte la méthode

            if (nb > nbAllumettes) // Vérifie si le joueur tente de prendre plus d'allumettes qu'il n'en reste
            {
                MessageBox.Show($"Vous ne pouvez pas prendre {nb} allumettes ! Il n'en reste que {nbAllumettes}.", "Erreur"); // Affiche un message d'erreur si le choix est invalide
                return;
            }

            nbAllumettes -= nb; // Réduit le nombre d'allumettes restantes par le nombre pris
            if (tourJoueur)
            {
                lblStatus!.Text = $"Tour {numeroTour} - Joueur a pris {nb} allumette(s)"; // Met à jour l'étiquette de statut pour indiquer que le joueur a pris nb allumettes. ! indique que lblStatus n'est pas null
            }
            else // Si c'est le tour de l'ordinateur
            {
                lblStatus!.Text = $"Tour {numeroTour} - Ordinateur a pris {nb} allumette(s)"; // Met à jour l'étiquette de statut pour indiquer que l'ordinateur a pris nb allumettes
            }

            MettreAJourAffichage(); // Appelle la méthode pour mettre à jour l'affichage (étiquettes, boutons, panneau)

            if (Fin()) // Vérifie si le jeu est terminé après ce tour
            {
                AfficherResultat(); // Affiche le résultat final si le jeu est terminé
                return;
            }

            tourJoueur = !tourJoueur; // Change le tour (du joueur à l'ordinateur ou vice-versa)
            numeroTour++; // Incrémente le numéro du tour

            if (!tourJoueur) // Si c'est maintenant le tour de l'ordinateur
            {
                int nbOrdi = Ordi(); // Appelle la méthode Ordi pour déterminer combien d'allumettes l'ordinateur prend
                System.Threading.Thread.Sleep(1000); // Pause de 1 seconde pour simuler la "réflexion" de l'ordinateur
                JouerTour(nbOrdi); // Appelle JouerTour pour effectuer le tour de l'ordinateur avec le nombre choisi
            }
        }

        // Méthode pour mettre à jour les éléments graphiques après un tour
        private void MettreAJourAffichage() 
        {
            lblAllumettes!.Text = $"Allumettes restantes : {nbAllumettes}"; // Met à jour l'étiquette pour afficher le nombre d'allumettes restantes
            btnPrendre1!.Enabled = nbAllumettes >= 1; // Active ou désactive le bouton "Prendre 1" selon qu'il reste au moins 1 allumette
            btnPrendre2!.Enabled = nbAllumettes >= 2; // "" "Prendre 2" "" 2 allumettes
            btnPrendre3!.Enabled = nbAllumettes >= 3; // " " "Prendre 3" " " 3 allumettes
            panelAllumettes!.Invalidate(); // Force le panneau à se redessiner en déclenchant l'événement Paint (appelle DessinerAllumettes)
        }

        // Méthode pour déterminer combien d'allumettes l'ordinateur prend
        private int Ordi() 
        {
            Random hasard = new Random(); // Crée un nouvel objet Random pour générer des nombres aléatoires
            int maxNb = Math.Min(3, nbAllumettes); // Calcule le maximum d'allumettes que l'ordinateur peut prendre (3 ou le nombre restant, le plus petit)
            return hasard.Next(1, maxNb + 1); // Retourne un nombre aléatoire entre 1 et maxNb inclus
        }

        // Méthode pour afficher le résultat final du jeu
        private void AfficherResultat() 
        {
            btnPrendre1!.Enabled = false; // Désactive le bouton "Prendre 1"
            btnPrendre2!.Enabled = false; // Désactive le bouton "Prendre 2"
            btnPrendre3!.Enabled = false; // Désactive le bouton "Prendre 3"
            btnRejouer!.Visible = true; // Rend le bouton "Rejouer" visible

            string message; // Déclare une variable pour stocker le message de résultat
            if (tourJoueur) // Si le joueur a pris la dernière allumette (tourJoueur est true après changement de tour)
            {
                message = "Vous avez pris la dernière allumette... Défaite ! 😞"; // Définit le message de défaite
            }
            else // Si l'ordinateur a pris la dernière allumette
            {
                message = "L'ordinateur a pris la dernière allumette ! Victoire ! 🎉"; // Définit le message de victoire
            }
            lblStatus!.Text = message; // Met à jour l'étiquette de statut avec le message de résultat
            MessageBox.Show(message, "Fin du jeu"); // Affiche une boîte de dialogue avec le message de résultat
        }

        // Méthode pour réinitialiser le jeu pour une nouvelle partie
        private void Rejouer() 
        {
            InitializeGame(); // Réinitialise l'état du jeu (allumettes, tour, numéro de tour)
            btnPrendre1!.Enabled = true; // Réactive le bouton "Prendre 1"
            btnPrendre2!.Enabled = true; // Réactive le bouton "Prendre 2"
            btnPrendre3!.Enabled = true; // Réactive le bouton "Prendre 3"
            btnRejouer!.Visible = false; // Cache le bouton "Rejouer"
            lblStatus!.Text = "Tour 1 - Joueur : Choisissez 1, 2 ou 3 allumettes"; // Réinitialise l'étiquette de statut pour le premier tour
            MettreAJourAffichage(); // MAJ affichage pour refléter le nouvel état
        }

        // Point d'entrée principal de l'application
        public static void Main(string[] args) 
        {
            Application.Run(new JeuAllumettesForm()); // Lance l'application Windows Forms en créant et affichant une instance de JeuAllumettesForm
        }
    }
}