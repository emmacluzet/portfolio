# Calculatrice Scientifique  
Application Python avec interface graphique Tkinter et évaluation sécurisée via AST.

---

## Présentation

Cette application est une **calculatrice scientifique complète** développée en Python.  
Elle propose une interface simple, moderne et ergonomique grâce à Tkinter, tout en
offrant un moteur de calcul **sécurisé** basé sur un interpréteur AST personnalisé
(pas de `eval()` non filtré).

Elle permet d’effectuer :
- opérations classiques (+, -, ×, ÷, %, (), …)
- puissances et racines
- fonctions scientifiques (sin, cos, tan en degrés, ln, log, exp, sqrt…)
- gestion de la mémoire (M+, M-, MR, MC)
- raccourcis clavier
- gestion des erreurs claire et non bloquante

---

## Fonctionnalités principales

### Sécurité (AST)
Toutes les expressions mathématiques sont évaluées via un **Abstract Syntax Tree**
afin de bloquer toute exécution de code non autorisée.  
Seuls les opérateurs, constantes et fonctions validées sont permissibles.

### Fonctions disponibles
- Addition, soustraction, multiplication, division  
- Puissance `^` (converti en `**`)  
- Modulo, division entière  
- Racine carrée, carré, cube  
- Inverse `1/x`  
- Valeur absolue  
- Logarithmes (`ln`, `log`)  
- Exponentielle `exp`  
- Factorielles `fact()` / `factorial()`

### Fonctions trigonométriques (en degrés)
- `sin(x)`
- `cos(x)`
- `tan(x)` (avec protection pour angles non définis)

### Mémoire intégrée
- **MC** : effacer la mémoire  
- **MR** : rappeler  
- **M+** : ajouter  
- **M-** : soustraire  

### Gestion clavier
- Entrée = calcul  
- Effacer = Backspace  
- Escape = tout effacer  
- Nombres + opérateurs via clavier  
- Fonctions écrites lettre par lettre (`s`, `i`, `n` → `sin(`)

---

## Structure du projet
projetCalculatrice/
│
├── calculatrice_scientifique.py
├── Cahier-des-charges.pdf
├── Guide-utilisation.pdf
└── README.md 

---

## Installation

### Prérequis
- Python 3.8+
- Aucun module externe n’est requis
  (tout repose sur `tkinter`, `math`, `ast`, déjà intégrés à Python)

### Lancer l’application

```bash
python calculatrice_scientifique.py
