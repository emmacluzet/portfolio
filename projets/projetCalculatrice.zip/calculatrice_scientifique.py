# calculatrice_scientifique.py
"""
Auteur : Emma Cluzet
Calculatrice scientifique en Tkinter
- Évaluation sécurisée d'expressions via AST (pas d'eval non filtré)
- Gestion d'erreurs affichée proprement
- Fonctions scientifiques (sin, cos, tan en degrés), ln, log10, exp, sqrt, factorial, pi, abs
- Fonctions supplémentaires : mémoire (M+, M-, MR, MC), pourcentage, inverse, x^2, x^3
- Gestion clavier (touches numériques, opérateurs, Enter, Backspace, Escape)
"""

import tkinter as tk
from tkinter import messagebox
import math
import ast
import operator

# ---------------------------
# ÉVALUATION SÉCURISÉE D'EXPRESSION
# ---------------------------
# On réalise un petit interpréteur AST qui n'autorise que des opérations sûres.

# Fonctions autorisées exposées aux expressions (nom -> callable)
def trig_sin_deg(x): return math.sin(math.radians(x))
def trig_cos_deg(x): return math.cos(math.radians(x))
def trig_tan_deg(x):
    # protection contre tan(90 + k*180) qui tend vers l'infini
    ang = x % 180
    if abs(ang - 90) < 1e-9:
        raise ValueError("tan indefinie pour cet angle")
    return math.tan(math.radians(x))

SAFE_FUNCTIONS = {
    'sin': trig_sin_deg,
    'cos': trig_cos_deg,
    'tan': trig_tan_deg,
    'ln': lambda x: math.log(x),
    'log': lambda x: math.log10(x),
    'sqrt': lambda x: math.sqrt(x),
    'exp': lambda x: math.exp(x),
    'abs': lambda x: abs(x),
    'fact': lambda x: math.factorial(int(x)),
    # alias plus usuels
    'factorial': lambda x: math.factorial(int(x)),
}

# constantes autorisées
SAFE_CONSTANTS = {
    'pi': math.pi,
    'e': math.e,
}

# Opérateurs autorisés (ast operator node -> function)
SAFE_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
}

SAFE_UNARY = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

class SafeEval(ast.NodeVisitor):
    def visit(self, node):
        # permit typed dispatch
        method = 'visit_' + node.__class__.__name__
        visitor = getattr(self, method, self.generic_visit)
        return visitor(node)

    def visit_Module(self, node):
        if len(node.body) != 1:
            raise ValueError("Expression invalide")
        return self.visit(node.body[0])

    def visit_Expr(self, node):
        return self.visit(node.value)

    def visit_BinOp(self, node):
        left = self.visit(node.left)
        right = self.visit(node.right)
        op_type = type(node.op)
        if op_type in SAFE_OPERATORS:
            try:
                return SAFE_OPERATORS[op_type](left, right)
            except Exception as e:
                raise
        raise ValueError(f"Opérateur non autorisé: {op_type}")

    def visit_UnaryOp(self, node):
        operand = self.visit(node.operand)
        op_type = type(node.op)
        if op_type in SAFE_UNARY:
            return SAFE_UNARY[op_type](operand)
        raise ValueError("Opérateur unauthorisé")

    def visit_Call(self, node):
        # autoriser uniquement des appels simples à des fonctions sûres
        if isinstance(node.func, ast.Name):
            fname = node.func.id
            if fname not in SAFE_FUNCTIONS:
                raise ValueError(f"Fonction non autorisée: {fname}")
            func = SAFE_FUNCTIONS[fname]
            args = [self.visit(a) for a in node.args]
            try:
                return func(*args)
            except Exception as e:
                # convertir l'erreur en ValueError pour affichage
                raise ValueError(str(e))
        raise ValueError("Appel de fonction non autorisé")

    def visit_Name(self, node):
        if node.id in SAFE_CONSTANTS:
            return SAFE_CONSTANTS[node.id]
        raise ValueError(f"Nom non autorisé: {node.id}")

    def visit_Constant(self, node):
        # python 3.8+: Constantes (int, float)
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError("Constante non autorisée")

    # Pour compatibilité plus ancienne si Num node présent
    def visit_Num(self, node):
        return node.n

    def generic_visit(self, node):
        raise ValueError(f"Expression non autorisée: {node.__class__.__name__}")

def safe_eval(expr: str):
    """
    Évalue l'expression mathématique fournie en chaîne en utilisant AST sécurisé.
    Autorise : + - * / ** % // (), constantes pi/e, fonctions de SAFE_FUNCTIONS.
    """
    # Nettoyage simple : remplacer '^' par '**' si utilisateur l'utilise
    expr = expr.replace('^', '**')
    # remplacer '√' par sqrt si utilisé
    expr = expr.replace('√', 'sqrt')
    # autoriser éventuellement 'π' to pi
    expr = expr.replace('π', 'pi')
    # remplacer '×' et '÷' si collés depuis un copier-coller
    expr = expr.replace('×', '*').replace('÷', '/')
    # parse
    try:
        parsed = ast.parse(expr, mode='exec')
        evaluator = SafeEval()
        result = evaluator.visit(parsed)
        return result
    except Exception as e:
        # rejaillir une erreur plus lisible
        raise ValueError(f"Erreur d'évaluation: {e}")

# ---------------------------
# INTERFACE GRAPHIQUE
# ---------------------------
class Calculatrice:
    def __init__(self, master):
        self.master = master
        master.title("Calculatrice Scientifique")
        master.geometry("420x520")
        master.configure(bg="#f6f6f6")

        # mémoire simple
        self.memory = 0.0

        # zone d'affichage
        self.entry = tk.Entry(master, font=("Segoe UI", 20), width=18, borderwidth=0, relief="flat", justify="right",
                              bg="#FFFFFF", fg="#222222")
        self.entry.grid(row=0, column=0, columnspan=6, padx=10, pady=12, sticky="nsew")

        # message d'état (erreur / info)
        self.status = tk.Label(master, text="", anchor="e", font=("Segoe UI", 9), fg="#a33a3a", bg="#f6f6f6")
        self.status.grid(row=1, column=0, columnspan=6, padx=10, sticky="ew")

        # boutons : définition (texte, commande, style_tag)
        btn_layout = [
            [("MC", self.mc, "clear"), ("MR", self.mr, "clear"), ("M+", self.mplus, "clear"), ("M-", self.mminus, "clear"), ("%", lambda: self.insert_text("%"), "operator"), ("C", self.clear_all, "clear")],
            [("7", lambda: self.insert_text("7"), "number"), ("8", lambda: self.insert_text("8"), "number"), ("9", lambda: self.insert_text("9"), "number"), ("/", lambda: self.insert_text("/"), "operator"), ("^", lambda: self.insert_text("^"), "operator"), ("←", self.backspace, "clear")],
            [("4", lambda: self.insert_text("4"), "number"), ("5", lambda: self.insert_text("5"), "number"), ("6", lambda: self.insert_text("6"), "number"), ("*", lambda: self.insert_text("*"), "operator"), ("(", lambda: self.insert_text("("), "operator"), (")", lambda: self.insert_text(")"), "operator")],
            [("1", lambda: self.insert_text("1"), "number"), ("2", lambda: self.insert_text("2"), "number"), ("3", lambda: self.insert_text("3"), "number"), ("-", lambda: self.insert_text("-"), "operator"), ("1/x", self.inverse, "function"), ("x²", self.square, "function")],
            [("0", lambda: self.insert_text("0"), "number"), (".", lambda: self.insert_text("."), "number"), ("+/-", self.negate, "function"), ("+", lambda: self.insert_text("+"), "operator"), ("x³", self.cube, "function"), ("=", self.equal, "equals")],
            [("sin", lambda: self.insert_text("sin("), "function"), ("cos", lambda: self.insert_text("cos("), "function"), ("tan", lambda: self.insert_text("tan("), "function"),
             ("ln", lambda: self.insert_text("ln("), "function"), ("log", lambda: self.insert_text("log("), "function"), ("√", lambda: self.insert_text("sqrt("), "function")]
        ]

        # couleurs par type
        self.button_colors = {"number": "#ffffff", "operator": "#f0f0f0", "function": "#ffd6f0", "equals": "#d6336c", "clear": "#ff8b94"}

        # placement boutons
        for r, row in enumerate(btn_layout, start=2):
            for c, (text, cmd, tag) in enumerate(row):
                color = self.button_colors.get(tag, "#ffffff")
                fg = "white" if tag == "equals" else "#222222"
                btn = tk.Button(master, text=text, command=cmd, width=6, height=2, font=("Segoe UI", 11),
                                bg=color, fg=fg, relief="flat", activebackground="#ffeef6")
                btn.grid(row=r, column=c, padx=4, pady=4, sticky="nsew")
        
        # configuration grid pour être responsive
        total_rows = 2 + len(btn_layout)
        total_cols = 6
        for i in range(total_cols):
            master.grid_columnconfigure(i, weight=1)
        for i in range(total_rows + 1):
            master.grid_rowconfigure(i, weight=1)

        # raccourcis clavier
        master.bind("<Return>", lambda e: self.equal())
        master.bind("<KP_Enter>", lambda e: self.equal())
        master.bind("<BackSpace>", lambda e: self.backspace())
        master.bind("<Escape>", lambda e: self.clear_all())
        master.bind("<Key>", self.key_pressed)

    # -------------
    # Fonctions d'interface
    # -------------
    def insert_text(self, txt):
        # Remplace % par /100 lors de l'évaluation mais laisse l'utilisateur voir %
        self.entry.insert(tk.END, txt)
        self.status.config(text="")

    def clear_all(self):
        self.entry.delete(0, tk.END)
        self.status.config(text="")

    def backspace(self):
        cur = self.entry.get()
        if cur:
            self.entry.delete(len(cur)-1, tk.END)
        self.status.config(text="")

    def negate(self):
        """inserer une négation autour du dernier nombre si possible"""
        expr = self.entry.get()
        if not expr:
            self.insert_text("-")
            return
        # cas simple : si selection ou dernier token est un nombre on le transforme en ( -number )
        # pour simplicité on ajoute un '-' si dernier char n'est operator
        if expr[-1].isdigit() or expr[-1] == ')':
            # essayer d'entourer le dernier opérande ; ici on simplifie en ajoutant "*-1" si adapté
            # mais pour rester simple : on insère '(-' au début si possible
            self.entry.insert(tk.END, "*-1")
        else:
            # si dernier char est un opérateur, ajouter '-' pour commencer un nombre négatif
            self.entry.insert(tk.END, "-")

    # ----------------
    # Fonctions math utiles
    # ----------------
    def inverse(self):
        expr = self.entry.get().strip()
        if not expr:
            self.status.config(text="Rien à inverser")
            return
        try:
            val = self._evaluate_expression(expr)
            if val == 0:
                raise ZeroDivisionError("Division par zéro")
            self.entry.delete(0, tk.END)
            self.entry.insert(0, str(1/val))
            self.status.config(text="")
        except Exception as e:
            self._report_error(e)

    def square(self):
        expr = self.entry.get().strip()
        if not expr:
            self.status.config(text="Rien à élever au carré")
            return
        try:
            val = self._evaluate_expression(expr)
            self.entry.delete(0, tk.END)
            self.entry.insert(0, str(val**2))
            self.status.config(text="")
        except Exception as e:
            self._report_error(e)

    def cube(self):
        expr = self.entry.get().strip()
        if not expr:
            self.status.config(text="Rien à élever au cube")
            return
        try:
            val = self._evaluate_expression(expr)
            self.entry.delete(0, tk.END)
            self.entry.insert(0, str(val**3))
            self.status.config(text="")
        except Exception as e:
            self._report_error(e)

    # ----------------
    # Mémoire
    # ----------------
    def mc(self):
        self.memory = 0.0
        self.status.config(text="Mémoire effacée")

    def mr(self):
        # afficher en entrée la valeur mémoire (retirer la notation scientifique si possible)
        self.entry.delete(0, tk.END)
        self.entry.insert(0, str(self.memory))
        self.status.config(text="Mémoire rappelée")

    def mplus(self):
        try:
            val = self._evaluate_expression(self.entry.get())
            self.memory += val
            self.status.config(text=f"M+ (mémoire = {self.memory})")
        except Exception as e:
            self._report_error(e)

    def mminus(self):
        try:
            val = self._evaluate_expression(self.entry.get())
            self.memory -= val
            self.status.config(text=f"M- (mémoire = {self.memory})")
        except Exception as e:
            self._report_error(e)

    # ----------------
    # Égal, évaluation
    # ----------------
    def equal(self):
        expr = self.entry.get().strip()
        if not expr:
            self.status.config(text="Rien à calculer")
            return
        try:
            result = self._evaluate_expression(expr)
            # formatage propre du résultat (éviter 1.0 -> 1 si entier)
            if isinstance(result, float):
                if abs(result - round(result)) < 1e-12:
                    result = int(round(result))
                else:
                    # limiter le nombre de décimales affichées raisonnablement
                    result = round(result, 10)
            self.entry.delete(0, tk.END)
            self.entry.insert(0, str(result))
            self.status.config(text="")
        except Exception as e:
            self._report_error(e)

    def _evaluate_expression(self, expr: str):
        """
        Prétraitements simples puis appel à safe_eval
        - Supporte le symbole % : on remplace 'x%' par '(x/100)'
        - Supporte 'π' et '^' gérés dans safe_eval
        """
        # Transformation simple pour % : remplacer "nombre%" par "(nombre/100)"
        # On remplace occurrences comme '50%' -> '(50/100)'
        # Implémentation basique : scan et replace
        i = 0
        new = ""
        while i < len(expr):
            ch = expr[i]
            if ch == '%':
                # si précédent est un chiffre ou ')', on remplace par '/100'
                new += "/100"
                i += 1
            else:
                new += ch
                i += 1
        # autoriser quelques caractères usuels ; le safe_eval lèvera une erreur si presence non permise
        new_expr = new
        return safe_eval(new_expr)

    # ----------------
    # Gestion erreurs / affichage
    # ----------------
    def _report_error(self, exc):
        # Afficher l'erreur en status et ne pas planter l'application
        msg = str(exc)
        # raccourcir les messages internes trop verbeux
        if msg.startswith("Erreur d'évaluation:"):
            msg = msg.replace("Erreur d'évaluation:", "").strip()
        # afficher une version lisible
        self.status.config(text=f"Erreur: {msg}")

    # ----------------
    # Gestion clavier
    # ----------------
    def key_pressed(self, event):
        allowed = "0123456789+-*/().%^"
        c = event.char
        if c in allowed:
            self.insert_text(c)
        elif event.keysym in ("Return", "KP_Enter"):
            self.equal()
        elif event.keysym == "BackSpace":
            self.backspace()
        elif event.keysym == "Escape":
            self.clear_all()
        # permettre des lettres pour fonctions (sin, cos, ln...) : on les ajoute lettre par lettre
        elif c.isalpha():
            self.insert_text(c)

# ---------------------------
# LANCEMENT
# ---------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = Calculatrice(root)
    root.mainloop()
